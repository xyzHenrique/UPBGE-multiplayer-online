|--------------------------------------------|
|-multiplayer online BASIC | client / server |
|--------------------------------------------|

|-------------------------------------------------------------------|
|-creator: Henrique Rodrigues (HenryQFX)                            | 
|-channel: https://www.youtube.com/channel/UCc39h8udpdOLwfU-u-X8Bbg |
|-github: https://github.com/HenryQFX                               |
|-------------------------------------------------------------------|

important: feel free to study code and change. but remember to leave the credits to the creator (HenryQFX)
